% brute force
close all;
clear All;
clc;
tic;
img = imread('pic4.jpg');
img_results = zeros(size(img));
figure,imshow(img);
img_gray = rgb2gray(img);
for c = 1:3
img_results(:,:,c) = brute(img(:,:,c));
end
figure, imshow(uint8(img_results));
title('brute');
toc;

% seperable filter

% close all;
% clear All;
% clc;
tic;
img = imread('pic4.jpg');
img_results = zeros(size(img));
% figure,imshow(img);
img_gray = rgb2gray(img);
for c = 1:3
img_results(:,:,c) = bilateralFilter(img(:,:,c));
end
figure, imshow(uint8(img_results));
title('seperable');
toc;

% box kernel
% close all;
% clear All;
% clc;
tic;
img = imread('pic4.jpg');
img_results = zeros(size(img));
% figure,imshow(img);
img_gray = rgb2gray(img);
for c = 1:3
img_results(:,:,c) = box(img(:,:,c));
end
figure, imshow(uint8(img_results));
title('box');
toc;